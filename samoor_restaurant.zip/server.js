/**
 * САМООР RESTAURANT ORDERING SYSTEM - NODE.JS/EXPRESS SERVER
 * Serves frontend static assets and secures Telegram Bot API routing.
 */

const express = require('express');
const cors = require('cors');
require('dotenv').config();

// Try importing node-fetch for older Node.js runtimes, otherwise use native fetch
let fetchApi;
if (typeof fetch !== 'undefined') {
  fetchApi = fetch;
} else {
  fetchApi = require('node-fetch');
}

const app = express();
app.set('trust proxy', true);
const PORT = process.env.PORT || 8000;

const fs = require('fs');
const path = require('path');

// Database Files paths
const dishesFilePath = path.join(__dirname, 'dishes.json');
const promosFilePath = path.join(__dirname, 'promos.json');

let dishesDb = [];
let promosDb = [];

// Load dishes
try {
  if (fs.existsSync(dishesFilePath)) {
    dishesDb = JSON.parse(fs.readFileSync(dishesFilePath, 'utf-8'));
    console.log(`Loaded ${dishesDb.length} dishes from database.`);
  } else {
    console.log('No dishes.json database found.');
  }
} catch (err) {
  console.error('Error loading dishes.json:', err);
}

// Load promos
try {
  if (fs.existsSync(promosFilePath)) {
    promosDb = JSON.parse(fs.readFileSync(promosFilePath, 'utf-8'));
    console.log(`Loaded ${promosDb.length} promos from database.`);
  } else {
    console.log('No promos.json database found.');
  }
} catch (err) {
  console.error('Error loading promos.json:', err);
}

// Load stats database
const statsFilePath = path.join(__dirname, 'stats.json');
let statsDb = {
  visits: {
    dine_in: 0,
    delivery: 0
  },
  orders: {
    dine_in: 0,
    delivery: 0
  },
  revenue: 0
};

try {
  if (fs.existsSync(statsFilePath)) {
    statsDb = JSON.parse(fs.readFileSync(statsFilePath, 'utf-8'));
    console.log('Stats database loaded successfully.');
  } else {
    console.log('No stats.json database found. Initializing empty.');
    fs.writeFileSync(statsFilePath, JSON.stringify(statsDb, null, 2), 'utf-8');
  }
} catch (err) {
  console.error('Error loading stats.json:', err);
}

function saveStatsDb() {
  fs.writeFile(statsFilePath, JSON.stringify(statsDb, null, 2), 'utf-8', (err) => {
    if (err) console.error('Error saving stats.json:', err);
  });
}

// Helper to save databases
function saveDishesDb() {
  fs.writeFile(dishesFilePath, JSON.stringify(dishesDb, null, 2), 'utf-8', (err) => {
    if (err) console.error('Error saving dishes.json:', err);
  });
}

function savePromosDb() {
  fs.writeFile(promosFilePath, JSON.stringify(promosDb, null, 2), 'utf-8', (err) => {
    if (err) console.error('Error saving promos.json:', err);
  });
}

// Enable CORS and JSON parsing
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// 1. SECURITY MIDDLEWARE: Block access to backend configuration files
app.use((req, res, next) => {
  const blockedPaths = [
    '/server.js',
    '/package.json',
    '/package-lock.json',
    '/.env',
    '/.gitignore',
    '/netlify'
  ];
  
  const requestPath = req.path.toLowerCase();
  
  if (blockedPaths.some(p => requestPath === p || requestPath.startsWith(p + '/'))) {
    return res.status(403).send('Access Denied: You are not authorized to access this resource.');
  }
  
  next();
});

// 2. SERVE STATIC FRONTEND FILES
const publicDir = path.join(__dirname, 'public');

if (fs.existsSync(publicDir) && fs.statSync(publicDir).isDirectory()) {
  console.log('Serving static files from /public folder...');
  app.use(express.static(publicDir));
}
// Redirect /admin to /admin/ relatively to prevent HTTP protocol downgrade on reverse proxies
app.get('/admin', (req, res, next) => {
  if (req.path === '/admin') {
    return res.redirect(302, '/admin/');
  }
  next();
});

// Explicitly serve admin/index.html to ensure reliability across all setups
app.get('/admin/', (req, res) => {
  const rootAdminPath = path.join(__dirname, 'admin', 'index.html');
  const publicAdminPath = path.join(publicDir, 'admin', 'index.html');
  
  if (fs.existsSync(publicAdminPath)) {
    return res.sendFile(publicAdminPath);
  } else if (fs.existsSync(rootAdminPath)) {
    return res.sendFile(rootAdminPath);
  } else {
    return res.status(404).send('Admin panel files not found on the server.');
  }
});
// Fall back to root directory serving so that /admin is always accessible
app.use(express.static(__dirname));

// 3. SECURE TELEGRAM API ROUTING ENDPOINT
app.post('/api/order', async (req, res) => {
  try {
    const payload = req.body;
    const token = process.env.TELEGRAM_BOT_TOKEN;
    const chatId = process.env.TELEGRAM_CHAT_ID;

    // Verify server config exists
    if (!token || !chatId) {
      return res.status(500).json({ error: 'Telegram credentials (TELEGRAM_BOT_TOKEN/CHAT_ID) are not configured on the server.' });
    }

    let messageText = "";

    if (payload.type === 'waiter') {
      messageText = `🔔 *ВЫЗОВ ОФИЦИАНТА*\n------------------------------\n📍 *Столик №:* ${payload.tableNumber}`;
    } else if (payload.type === 'support') {
      messageText = `🚨 *ОБРАЩЕНИЕ В ПОДДЕРЖКУ*\n------------------------------\n📞 *Телефон:* ${payload.phone}\n💬 *Проблема:*\n${payload.message}`;
    } else {
      // Order type
      const order = payload.orderData;
      
      // Update statistics
      try {
        if (order.mode === 'dine_in' || order.mode === 'dine-in') {
          statsDb.orders.dine_in++;
        } else {
          statsDb.orders.delivery++;
        }
        // If USD order, convert total back to KGS (without the 20% markup) for statistics
        const conversionRate = 89;
        const kgsTotal = order.currency === "USD" ? (order.total * conversionRate) / 1.2 : order.total;
        statsDb.revenue += Number(kgsTotal) || 0;
        saveStatsDb();
      } catch (statsErr) {
        console.error('Failed to update stats on order:', statsErr);
      }

      const formatBackendPrice = (price, curr) => {
        const num = parseFloat(price);
        if (isNaN(num)) return price;
        return curr === "USD" ? `$${num.toFixed(2)}` : `${Math.round(num)} сом`;
      };

      let itemsList = "";
      order.items.forEach((item, idx) => {
        itemsList += `${idx + 1}. *${item.name}* x${item.quantity} — ${formatBackendPrice(item.price * item.quantity, order.currency)}\n`;
      });

      const prefText = order.communication === "call" ? "Позвонить мне" : "Только написать";
      
      let payText = "";
      if (order.payment.method === "cash") {
        payText = `Наличными (${order.payment.no_change ? 'Без сдачи' : 'Сдача с ' + formatBackendPrice(order.payment.change_from, order.currency)})`;
      } else if (order.payment.method === "card") {
        payText = "Картой курьеру";
      } else {
        payText = "Оплата по QR коду";
      }

      messageText = `🔔 *НОВЫЙ ЗАКАЗ #${order.orderId}*\n` +
                    `------------------------------\n` +
                    `👤 *Имя:* ${order.customer.name}\n` +
                    `📞 *Телефон:* ${order.customer.phone}\n` +
                    `📍 *Адрес:* ${order.customer.address}\n` +
                    `📞 *Связь:* ${prefText}\n` +
                    `💳 *Оплата:* ${payText}\n` +
                    (order.promo_code ? `🎟️ *Промокод:* ${order.promo_code} (-${formatBackendPrice(order.promo_discount, order.currency)})\n` : '') +
                    (order.customer.comment ? `💬 *Комментарий:* ${order.customer.comment}\n` : '') +
                    `📦 *Блюда:*\n${itemsList}` +
                    `🚗 *Доставка:* ${order.delivery === 0 ? 'Бесплатно' : formatBackendPrice(order.delivery, order.currency)}\n` +
                    `💰 *Итого к оплате:* *${formatBackendPrice(order.total, order.currency)}*`;
    }

    const apiURL = `https://api.telegram.org/bot${token}/sendMessage`;
    
    let data;
    try {
      const response = await fetchApi(apiURL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text: messageText,
          parse_mode: 'Markdown'
        })
      });
      
      data = await response.json();
      
      if (!response.ok || !data.ok) {
        console.error('Telegram Bot API Error Response:', data);
        return res.status(500).json({ 
          error: `Telegram Bot API Error: ${data.description || 'Unknown error'}` 
        });
      }
    } catch (fetchError) {
      console.error('Network error requesting Telegram Bot API:', fetchError);
      return res.status(500).json({ 
        error: `Network Error: Failed to connect to Telegram server (${fetchError.message})` 
      });
    }

    return res.status(200).json({ success: true, messageId: data.result.message_id });
  } catch (error) {
    console.error('Error handling Telegram proxy dispatch:', error);
    return res.status(500).json({ error: error.message });
  }
});

// ==========================================================================
// BACKEND API ENDPOINTS (DISHES & PROMO CODES CRUD)
// ==========================================================================

// 1. GET ALL DISHES
app.get('/api/dishes', (req, res) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  return res.status(200).json(dishesDb);
});

// 2. CREATE A DISH
app.post('/api/dishes', (req, res) => {
  try {
    const newDish = req.body;
    if (!newDish.name || !newDish.price || !newDish.category) {
      return res.status(400).json({ error: 'Missing required dish fields (name, price, category).' });
    }
    // Generate a unique ID
    newDish.id = 'dish_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
    dishesDb.push(newDish);
    saveDishesDb();
    console.log(`Created new dish: ${newDish.name} (ID: ${newDish.id})`);
    return res.status(201).json(newDish);
  } catch (error) {
    console.error('Error in POST /api/dishes:', error);
    return res.status(500).json({ error: error.message });
  }
});

// 3. UPDATE A DISH
app.put('/api/dishes/:id', (req, res) => {
  try {
    const { id } = req.params;
    const updatedDish = req.body;
    const index = dishesDb.findIndex(d => d.id === id);
    
    if (index === -1) {
      return res.status(404).json({ error: `Dish with ID ${id} not found.` });
    }
    
    // Merge updated fields, keeping the original ID
    dishesDb[index] = { ...dishesDb[index], ...updatedDish, id };
    saveDishesDb();
    console.log(`Updated dish: ${dishesDb[index].name} (ID: ${id})`);
    return res.status(200).json(dishesDb[index]);
  } catch (error) {
    console.error('Error in PUT /api/dishes/:id:', error);
    return res.status(500).json({ error: error.message });
  }
});

// 4. DELETE A DISH
app.delete('/api/dishes/:id', (req, res) => {
  try {
    const { id } = req.params;
    const index = dishesDb.findIndex(d => d.id === id);
    
    if (index === -1) {
      return res.status(404).json({ error: `Dish with ID ${id} not found.` });
    }
    
    const deleted = dishesDb.splice(index, 1);
    saveDishesDb();
    console.log(`Deleted dish: ${deleted[0].name} (ID: ${id})`);
    return res.status(200).json({ success: true, message: `Dish with ID ${id} deleted.` });
  } catch (error) {
    console.error('Error in DELETE /api/dishes/:id:', error);
    return res.status(500).json({ error: error.message });
  }
});

// 5. GET ALL PROMO CODES
app.get('/api/promos', (req, res) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  return res.status(200).json(promosDb);
});

// 6. CREATE OR UPDATE A PROMO CODE (UPSERT)
app.post('/api/promos', (req, res) => {
  try {
    const promo = req.body;
    if (!promo.code || promo.discount_percent === undefined) {
      return res.status(400).json({ error: 'Missing required promo code fields (code, discount_percent).' });
    }
    
    // Normalize code to uppercase
    promo.code = promo.code.toUpperCase();
    
    const index = promosDb.findIndex(p => p.code === promo.code);
    if (index !== -1) {
      // Update existing promo
      promosDb[index] = { ...promosDb[index], ...promo };
      console.log(`Updated promo code: ${promo.code}`);
    } else {
      // Create new promo
      promosDb.push(promo);
      console.log(`Created new promo code: ${promo.code}`);
    }
    
    savePromosDb();
    return res.status(200).json(promo);
  } catch (error) {
    console.error('Error in POST /api/promos:', error);
    return res.status(500).json({ error: error.message });
  }
});

// 7. DELETE A PROMO CODE
app.delete('/api/promos/:code', (req, res) => {
  try {
    const code = req.params.code.toUpperCase();
    const index = promosDb.findIndex(p => p.code === code);
    
    if (index === -1) {
      return res.status(404).json({ error: `Promo code ${code} not found.` });
    }
    
    promosDb.splice(index, 1);
    savePromosDb();
    console.log(`Deleted promo code: ${code}`);
    return res.status(200).json({ success: true, message: `Promo code ${code} deleted.` });
  } catch (error) {
    console.error('Error in DELETE /api/promos/:code:', error);
    return res.status(500).json({ error: error.message });
  }
});

// 8. DIAGNOSTIC DIRECTORY CHECKER ROUTE
app.get('/api/debug-paths', (req, res) => {
  const getFiles = (dir, depth = 0) => {
    if (depth > 2) return [];
    let results = [];
    try {
      const list = fs.readdirSync(dir);
      list.forEach((file) => {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);
        if (stat && stat.isDirectory()) {
          results.push({ name: file, type: 'dir', path: filePath, children: getFiles(filePath, depth + 1) });
        } else {
          results.push({ name: file, type: 'file', path: filePath });
        }
      });
    } catch (e) {
      results.push({ error: e.message });
    }
    return results;
  };
  
  return res.json({
    __dirname,
    cwd: process.cwd(),
    files: getFiles(__dirname)
  });
});

// 9. MONITORING STATS ENDPOINTS
app.post('/api/stats/visit', (req, res) => {
  try {
    const { mode } = req.body;
    if (mode === 'dine_in' || mode === 'dine-in') {
      statsDb.visits.dine_in++;
    } else if (mode === 'delivery') {
      statsDb.visits.delivery++;
    }
    saveStatsDb();
    return res.status(200).json({ success: true, visits: statsDb.visits });
  } catch (error) {
    console.error('Error in POST /api/stats/visit:', error);
    return res.status(500).json({ error: error.message });
  }
});

app.get('/api/stats', (req, res) => {
  return res.status(200).json(statsDb);
});

// 10. SECURE IMGBB IMAGE UPLOAD PROXY
app.post('/api/upload', async (req, res) => {
  try {
    const { image } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'Missing image field in request body.' });
    }

    const apiKey = process.env.IMGBB_API_KEY;
    if (!apiKey) {
      console.error('ImgBB Upload Error: IMGBB_API_KEY is not defined in environment variables.');
      return res.status(500).json({ error: 'ImgBB API key is not configured on the server.' });
    }

    // Strip prefix if present (e.g. "data:image/jpeg;base64,")
    let base64Data = image;
    if (base64Data.includes(';base64,')) {
      base64Data = base64Data.split(';base64,')[1];
    }

    const bodyParams = new URLSearchParams();
    bodyParams.append('image', base64Data);

    console.log('Forwarding image upload request to ImgBB...');
    const imgbbRes = await fetchApi(`https://api.imgbb.com/1/upload?key=${apiKey}`, {
      method: 'POST',
      body: bodyParams
    });

    const data = await imgbbRes.json();
    
    if (imgbbRes.ok && data && data.success && data.data && data.data.display_url) {
      console.log('Image uploaded successfully to ImgBB:', data.data.display_url);
      return res.status(200).json({ display_url: data.data.display_url });
    } else {
      const errMsg = (data && data.error && data.error.message) || 'Unknown error from ImgBB';
      console.error('ImgBB API Failure:', errMsg);
      return res.status(500).json({ error: errMsg });
    }
  } catch (error) {
    console.error('Error in POST /api/upload proxy:', error);
    return res.status(500).json({ error: error.message });
  }
});

// START EXPRESS WEB SERVER
app.listen(PORT, () => {
  console.log(`==================================================`);
  console.log(`SAMOOR Express Server successfully started!`);
  console.log(`Listening on http://localhost:${PORT}`);
  console.log(`==================================================`);
});
