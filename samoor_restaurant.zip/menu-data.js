const CATEGORIES = {
  breakfasts: { id: "breakfasts", name: "Завтраки", icon: "coffee" },
  salads: { id: "salads", name: "Салаты", icon: "leaf" },
  soups: { id: "soups", name: "Супы", icon: "soup" },
  mains: { id: "mains", name: "Вторые блюда", icon: "utensils" },
  steaks: { id: "steaks", name: "Стейки", icon: "beef" },
  pizza: { id: "pizza", name: "Пицца", icon: "pizza" },
  kids: { id: "kids", name: "Детское меню", icon: "smile" },
  grill: { id: "grill", name: "Шашлык", icon: "flame" },
  sets: { id: "sets", name: "Сеты", icon: "star" },
  starters: { id: "starters", name: "Закуски", icon: "leaf" },
  bakery: { id: "bakery", name: "Выпечка & Сладости", icon: "coffee" },
  sides: { id: "sides", name: "Гарниры & Соусы", icon: "utensils" },
  drinks: { id: "drinks", name: "Напитки & Чай", icon: "glass" },
  marinades: { id: "marinades", name: "Маринады", icon: "flame" }
};

const MENU_DATA = [
  {
    "id": "br-1",
    "category": "breakfasts",
    "name": "Омлет с сыром",
    "price": 288,
    "portion": "",
    "description": "Яицо кур., сливки, сыр моц., микс салат, соус лимонный",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-2",
    "category": "breakfasts",
    "name": "Не испанский завтрак",
    "price": 488,
    "portion": "",
    "description": "Яйцо куриное, сливки, картофель, микс салат, соус лимонный, тостерный хлеб, сыр творожный, семга копченая, сыр пармезан",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-3",
    "category": "breakfasts",
    "name": "Сырники с йогуртом",
    "price": 318,
    "portion": "",
    "description": "Творог, яйцо, сахар, мука, йогурт, вишня коктейльная",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-4",
    "category": "breakfasts",
    "name": "Блинчики со сметаной",
    "price": 219,
    "portion": "",
    "description": "Яйцо куриное, масло растительное, молоко, мука, сметана",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-5",
    "category": "breakfasts",
    "name": "Блинчики с творогом",
    "price": 288,
    "portion": "",
    "description": "Яйцо куриное, масло растительное, молоко, творог",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-6",
    "category": "breakfasts",
    "name": "Шакшука",
    "price": 388,
    "portion": "",
    "description": "Помидоры, лук, перец болгарский, томатная паста, яйцо, тостерный хлеб, лук зелёный, базилик, кинза",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-7",
    "category": "breakfasts",
    "name": "Английский завтрак",
    "price": 478,
    "portion": "",
    "description": "Яйцо куриное, сосиски «Тойбосс», микс салат, соус лимонный, огурец, корнишоны, тостерный хлеб, кетчуп, кукуруза консервированная",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-8",
    "category": "breakfasts",
    "name": "Каша рисовая",
    "price": 218,
    "portion": "",
    "description": "Рис, молоко, масло сливочное, сахар, гранола",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-9",
    "category": "breakfasts",
    "name": "Каша овсяная",
    "price": 218,
    "portion": "",
    "description": "Овсянка, масло сливочное, молоко, гранола",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-10",
    "category": "breakfasts",
    "name": "Каша из киноа",
    "price": 218,
    "portion": "",
    "description": "Киноа, масло сливочное, молоко, гранола",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "br-11",
    "category": "breakfasts",
    "name": "Гранола с йогуртом",
    "price": 348,
    "portion": "",
    "description": "Йогурт, гранола из тыквенных семечек и овсянки, банан, вишня коктейльная",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-12",
    "category": "salads",
    "name": "Свежий салат",
    "price": 248,
    "portion": "",
    "description": "Салат микс, огурцы, помидоры, лук репчатый, масло растительное",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-13",
    "category": "salads",
    "name": "Греческий салат",
    "price": 388,
    "portion": "",
    "description": "Микс салат, огурцы, помидоры, перец болгарский, лук красный, оливки, маслины, сыр «Фетакса», орегано, фирменный соус",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-14",
    "category": "salads",
    "name": "Китайский салат",
    "price": 388,
    "portion": "",
    "description": "Говядина, лук, перец полугорький, огурцы, помидоры, кунжут, масло растительное, соевый соус, чеснок, кинза",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-15",
    "category": "salads",
    "name": "Муэр",
    "price": 388,
    "portion": "",
    "description": "Грибы шиитаки, древесные грибы, огурцы, помидоры, лук, соевый соус, фирменный острый соус",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-16",
    "category": "salads",
    "name": "Салат с копчёной сёмгой",
    "price": 588,
    "portion": "",
    "description": "Микс салат, руккола, перец болгарский, соус «Цезарь», картофель, черри, яйцо перепелиное, сыр моцарелла, сёмга копчёная, лимонный соус, бальзамический крем",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-17",
    "category": "salads",
    "name": "Цезарь с курицей",
    "price": 448,
    "portion": "",
    "description": "Соус «Цезарь», айсберг, куриное филе, пармезан, яйцо перепелиное, сухари, черри",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-18",
    "category": "salads",
    "name": "Нисуаз с форелью",
    "price": 588,
    "portion": "",
    "description": "Микс салат, стейк форели, маслины, оливки, перец болгарский, лук красный, черри, яйцо перепелиное, яйцо пашот, соус лимонный",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-19",
    "category": "salads",
    "name": "Овощной салат с авокадо",
    "price": 488,
    "portion": "",
    "description": "Микс салат, брокколи, цветная капуста, перец болгарский, огурцы, черри, авокадо, соус винегрет",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-20",
    "category": "salads",
    "name": "Азиатский салат",
    "price": 418,
    "portion": "",
    "description": "Перец болгарский, огурцы, помидоры, говядина, лук репчатый, опята, соевый соус",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-21",
    "category": "salads",
    "name": "Аристократ",
    "price": 488,
    "portion": "",
    "description": "Огурцы, Черри, Лук красный, Микс салат,Болгарский перец, Грейпфрут,Фисташки, Сыр творожный, Соус фирменный",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-22",
    "category": "salads",
    "name": "Майо",
    "price": 418,
    "portion": "",
    "description": "Сыр голландский, яйцо варёное, вешенки, огурцы свежие, огурцы маринованные, куриная грудка,майонез, пармезан",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-23",
    "category": "salads",
    "name": "Хрустящий баклажан",
    "price": 418,
    "portion": "",
    "description": "Баклажан, черри, кинза, кисло-сладкий соус",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-24",
    "category": "salads",
    "name": "Нежный краб",
    "price": 348,
    "portion": "",
    "description": "Крабовые палочки, белокочанная капуста, куриное яйцо, майонез, кукуруза",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-25",
    "category": "salads",
    "name": "Горячая фунчоза",
    "price": 448,
    "portion": "",
    "description": "Фунчоза, болгарский перец, чеснок, говядина, репчатый лук, зелёный лук, соевый соус, перец чили",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sa-26",
    "category": "salads",
    "name": "Капрезе",
    "price": 488,
    "portion": "",
    "description": "Сыр моцарелла, помидоры, соус песто, руккола, фирменный соус, кедровый орех, бальзамический крем",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-27",
    "category": "soups",
    "name": "Перепелиный суп",
    "price": 388,
    "portion": "",
    "description": "Говядина, картофель, морковь, помидоры черри, перепелиное яйцо, бульон",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-28",
    "category": "soups",
    "name": "Чечевичный крем-суп",
    "price": 288,
    "portion": "",
    "description": "Томатная паста, чечевица, репчатый лук, морковь, сливки, лимон, сухарики, растительное масло",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-29",
    "category": "soups",
    "name": "Мампар",
    "price": 318,
    "portion": "",
    "description": "Тесто, говядина, репчатый лук, болгарский перец, зелень, томатная паста, бульон, морковь",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-30",
    "category": "soups",
    "name": "Шорпо из говядины",
    "price": 328,
    "portion": "",
    "description": "Говядина, картофель, лук, болгарский перец, морковь, укроп, бульон.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-31",
    "category": "soups",
    "name": "Шорпо из баранины",
    "price": 338,
    "portion": "",
    "description": "Баранина, картофель, лук, морковь, укроп, бульон.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-32",
    "category": "soups",
    "name": "Китайский суп",
    "price": 358,
    "portion": "",
    "description": "Говядина, чеснок, грибы шитаки, имбирь, чили, фунчоза.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-33",
    "category": "soups",
    "name": "Сливочный суп с форелью",
    "price": 448,
    "portion": "",
    "description": "Форель, виола, сливки, черри, укроп, картофель, морковь.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-34",
    "category": "soups",
    "name": "Чучбара острая",
    "price": 448,
    "portion": "",
    "description": "Говядина, полугорький перец, лук, морковь, томатная паста, кинза, чеснок, фунчоза.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-35",
    "category": "soups",
    "name": "Жидкий лагман",
    "price": 350,
    "portion": "450 мл",
    "description": "Лапша, болгарский перец, лук, басай, говядина,сельдерей,растительное масло, бульон,лапиза,чеснок.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-36",
    "category": "soups",
    "name": "Пельмени",
    "price": 318,
    "portion": "",
    "description": "Говядина , Лук репчатый , тесто , бульон , Сметана , укроп",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "so-37",
    "category": "soups",
    "name": "Том Ям с морепродуктами",
    "price": 690,
    "portion": "400 мл",
    "description": "Мидии, креветки, семга, форель, паста Том Ям, лайм, кокосовое молоко, рис, вода, лемонграсс, листья лайма, болгарский перец, репчатый лук, шампиньоны",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-38",
    "category": "mains",
    "name": "Мясо с овощами",
    "price": 488,
    "portion": "",
    "description": "Говядина, брюссельская капуста , болгарский перец, помидоры, огурцы, репчатый лук, соевый соус, растительное масло",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-39",
    "category": "mains",
    "name": "Куурдак из говядины",
    "price": 568,
    "portion": "",
    "description": "Говядина, репчатый лук, картофель, соевый соус, растительное масло",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-40",
    "category": "mains",
    "name": "Куурдак из баранины",
    "price": 618,
    "portion": "",
    "description": "Баранина, картофель, репчатый лук, соевый соус, растительное масло",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-41",
    "category": "mains",
    "name": "Картофель по-домашнему",
    "price": 348,
    "portion": "",
    "description": "Картофель, говядина, репчатый лук",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-42",
    "category": "mains",
    "name": "Казан-кебаб с говядиной",
    "price": 518,
    "portion": "",
    "description": "Говядина, рис, репчатый лук, соевый соус, растительное масло",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-43",
    "category": "mains",
    "name": "Мясо по-китайски",
    "price": 538,
    "portion": "",
    "description": "Говядина, репчатый лук, полугорький перец, огурцы, соевый соус, острый соус, рис",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-44",
    "category": "mains",
    "name": "Босо лагман",
    "price": 388,
    "portion": "",
    "description": "Говядина, болгарский перец, репчатый лук, басай,сельдерей,чинсай, лапша, соевый соус",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-45",
    "category": "mains",
    "name": "Медальоны",
    "price": 788,
    "portion": "",
    "description": "Бон филе,шампиньоны,шпинат ,кабачки, соус «Деми-глас», помидоры черри",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-46",
    "category": "mains",
    "name": "Телятина с картофелем",
    "price": 588,
    "portion": "",
    "description": "Говядина, репчатый лук, помидоры, огурцы, болгарский перец, картофель, помидоры черри,соевый соус",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-47",
    "category": "mains",
    "name": "Котлета по-киевски",
    "price": 478,
    "portion": "",
    "description": "Куриное филе, куриный окорочок, яйцо, сливочное масло, укроп, картофельное пюре, сливочный соус, помидоры черри",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-48",
    "category": "mains",
    "name": "Эскимо",
    "price": 438,
    "portion": "",
    "description": "Куриное филе, куриный окорочок, репчатый лук, яйцо, сливочный соус, помидоры черри, картофельное пюре.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-49",
    "category": "mains",
    "name": "Фрикасе с рисом",
    "price": 448,
    "portion": "",
    "description": "Куриное филе, вешенки, кукуруза, репчатый лук, сливки, рис, помидоры черри.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-50",
    "category": "mains",
    "name": "Бефстроганов с пюре",
    "price": 528,
    "portion": "",
    "description": "Говядина, репчатый лук, шампиньоны, корнишоны, сливки, помидоры черри, картофельное пюре.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-51",
    "category": "mains",
    "name": "Мясо с фри",
    "price": 518,
    "portion": "",
    "description": "Картофель фри, говядина, репчатый лук, болгарский перец, лапша.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-52",
    "category": "mains",
    "name": "Фахитос с говядиной",
    "price": 628,
    "portion": "",
    "description": "Говядина, репчатый лук, болгарский перец, чеснок, помидоры черри, острый соус,пико де гайо,соевый соус,лаваш.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-53",
    "category": "mains",
    "name": "Курица в кисло-сладком соусе",
    "price": 428,
    "portion": "",
    "description": "Куриное филе, помидоры черри, кисло-сладкий соус, рис, зелёный лук, чили",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-54",
    "category": "mains",
    "name": "Форель жаренный",
    "price": 788,
    "portion": "",
    "description": "Форель, микс салат, помидоры черри, лимонный соус, лимон.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-55",
    "category": "mains",
    "name": "Жареный рис",
    "price": 288,
    "portion": "",
    "description": "Куриное филе, зелёный лук, репчатый лук, болгарский перец, соевый соус.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-56",
    "category": "mains",
    "name": "Антрекот от шефа",
    "price": 828,
    "portion": "",
    "description": "Антрекот, кабачки, баклажан, помидоры черри, шампиньоны.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-57",
    "category": "mains",
    "name": "Кесадилья",
    "price": 380,
    "portion": "",
    "description": "Тортилья, курица, репчатый лук, шампиньоны, сыр моцарелла, соус «Сладкий чили», соус «Пико Де гайо».",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-58",
    "category": "mains",
    "name": "Манты с мясом",
    "price": 388,
    "portion": "говядина , репчатый лук, жир , специи, красный соус, тесто",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ma-59",
    "category": "mains",
    "name": "Манты 1 шт",
    "price": 78,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "st-60",
    "category": "steaks",
    "name": "Стейк из форели",
    "price": 890,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "st-61",
    "category": "steaks",
    "name": "Стейк из семги",
    "price": 1290,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "st-62",
    "category": "steaks",
    "name": "Тибон стейк",
    "price": 1690,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "st-63",
    "category": "steaks",
    "name": "Рибай стейк",
    "price": 1690,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "st-64",
    "category": "steaks",
    "name": "Ковбой стейк",
    "price": 1890,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "pi-65",
    "category": "pizza",
    "name": "4 Сыра",
    "price": 768,
    "portion": "",
    "description": "Чеддер, сыр сулугуни, сыр моцарелла, пармезан, тесто",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "pi-66",
    "category": "pizza",
    "name": "Цезарь",
    "price": 748,
    "portion": "",
    "description": "Курица, соус «Цезарь», айсберг, пармезан, сливки, сыр моцарелла, сыр сулугуни, помидоры черри, тесто",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "pi-67",
    "category": "pizza",
    "name": "Капрезе",
    "price": 748,
    "portion": "",
    "description": "Помидоры черри, тесто, соус песто, руккола, сыр моцарелла, сыр сулугуни, моцарелла в рассоле, сливки",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "pi-68",
    "category": "pizza",
    "name": "Фирменная «Самоор»",
    "price": 888,
    "portion": "",
    "description": "Тесто, грибы, колбаса, маслины, курица, болгарский перец, сыр моцарелла, сыр сулугуни, соус пицца.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "pi-69",
    "category": "pizza",
    "name": "Маргарита",
    "price": 528,
    "portion": "",
    "description": "Помидоры, соус пицца, сыр сулугуни, сыр моцарелла",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "pi-70",
    "category": "pizza",
    "name": "Пепперони",
    "price": 688,
    "portion": "",
    "description": "Тесто, соус «Пицца», пепперони, сыр сулугуни, сыр моцарелла",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "pi-71",
    "category": "pizza",
    "name": "Чили",
    "price": 718,
    "portion": "",
    "description": "Тесто, чили фарш, соус «Пицца», халапеньо, сыр сулугуни, сыр моцарелла",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "pi-72",
    "category": "pizza",
    "name": "Куриная",
    "price": 688,
    "portion": "",
    "description": "Тесто, сливки, шампиньоны, курица, сыр сулугуни, сыр моцарелла",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ki-73",
    "category": "kids",
    "name": "Наггетсы",
    "price": 318,
    "portion": "",
    "description": "Наггетсы, картофель фри, кетчуп.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ki-74",
    "category": "kids",
    "name": "Картофель фри с сосиской",
    "price": 318,
    "portion": "",
    "description": "Сосиски «Тойбосс», картофель фри, кетчуп.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ki-75",
    "category": "kids",
    "name": "Вареники",
    "price": 258,
    "portion": "",
    "description": "Тесто, картофель, репчатый лук, сметана.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ki-76",
    "category": "kids",
    "name": "Пельмени со сметаной",
    "price": 283,
    "portion": "",
    "description": "Тесто, говядина, репчатый лук, сметана.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ki-77",
    "category": "kids",
    "name": "Куриный суп",
    "price": 228,
    "portion": "",
    "description": "Курица, бульон, макароны, куриное филе, морковь.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-78",
    "category": "grill",
    "name": "Баранина на косточках",
    "price": 600,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-79",
    "category": "grill",
    "name": "Говядина",
    "price": 600,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-80",
    "category": "grill",
    "name": "Курица филе",
    "price": 490,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-81",
    "category": "grill",
    "name": "Курица на костях",
    "price": 450,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-82",
    "category": "grill",
    "name": "Крылышки",
    "price": 450,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-83",
    "category": "grill",
    "name": "Оромо кебаб",
    "price": 450,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-84",
    "category": "grill",
    "name": "Кебаб в лаваше",
    "price": 420,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-85",
    "category": "grill",
    "name": "Кебаб в рубашке",
    "price": 500,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-86",
    "category": "grill",
    "name": "Люля-кебаб",
    "price": 410,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-87",
    "category": "grill",
    "name": "Ассорти шашлыков",
    "price": 650,
    "portion": "лепёшка 2 кусочка, соус",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-88",
    "category": "grill",
    "name": "Утиная грудка",
    "price": 390,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-89",
    "category": "grill",
    "name": "Печень в рубашке",
    "price": 400,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-90",
    "category": "grill",
    "name": "Печень обычная",
    "price": 350,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-91",
    "category": "grill",
    "name": "Форель на мангале",
    "price": 1490,
    "portion": "целиком",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-92",
    "category": "grill",
    "name": "Мякоть баранины",
    "price": 650,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-93",
    "category": "grill",
    "name": "Антрекот",
    "price": 650,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-94",
    "category": "grill",
    "name": "Семечки",
    "price": 600,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-95",
    "category": "grill",
    "name": "Фирменный шашлык «Самоор»",
    "price": 700,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-96",
    "category": "grill",
    "name": "Овощи на мангале",
    "price": 360,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-97",
    "category": "grill",
    "name": "Картофель на мангале",
    "price": 220,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-98",
    "category": "grill",
    "name": "Кукуруза на мангале",
    "price": 220,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-99",
    "category": "grill",
    "name": "Шампиньоны на мангале",
    "price": 300,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-100",
    "category": "grill",
    "name": "Лепёшка на углях",
    "price": 100,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-101",
    "category": "grill",
    "name": "Шашлычный соус",
    "price": 80,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "gr-102",
    "category": "grill",
    "name": "Свежий лук",
    "price": 30,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-103",
    "category": "sets",
    "name": "Баранина на косточках",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-104",
    "category": "sets",
    "name": "Говядина",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-105",
    "category": "sets",
    "name": "Курица на костях",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-106",
    "category": "sets",
    "name": "Оромо-кебаб",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-107",
    "category": "sets",
    "name": "Люля-кебаб",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-108",
    "category": "sets",
    "name": "Кукуруза на мангале",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-109",
    "category": "sets",
    "name": "Картофель на мангале",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-110",
    "category": "sets",
    "name": "Лепёшка на углях",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-111",
    "category": "sets",
    "name": "Шашлычный соус",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-112",
    "category": "sets",
    "name": "Цена",
    "price": 3490,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-113",
    "category": "sets",
    "name": "Баранина на косточках",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-114",
    "category": "sets",
    "name": "Говядина",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-115",
    "category": "sets",
    "name": "Крылышки",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-116",
    "category": "sets",
    "name": "Кебаб в рубашке",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-117",
    "category": "sets",
    "name": "Утиная грудка",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-118",
    "category": "sets",
    "name": "Печень в рубашке",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-119",
    "category": "sets",
    "name": "Овощи на мангале",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-120",
    "category": "sets",
    "name": "Картофель на мангале",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-121",
    "category": "sets",
    "name": "Шампиньоны на мангале",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-122",
    "category": "sets",
    "name": "Лепёшка на углях",
    "price": 1,
    "portion": "целая",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-123",
    "category": "sets",
    "name": "Шашлычный соус",
    "price": 1,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-124",
    "category": "sets",
    "name": "Цена",
    "price": 4300,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "se-125",
    "category": "sets",
    "name": "Сет на компанию \"Куурдак из Баранины\"",
    "price": 3698,
    "portion": "",
    "description": "Баранина, картофель, репчатый лук, соевый соус, растительное масло",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sta-126",
    "category": "starters",
    "name": "Цезарь ролл",
    "price": 328,
    "portion": "",
    "description": "Тортилья, курица, айсберг, помидоры, соус «Цезарь»",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sta-127",
    "category": "starters",
    "name": "Клаб-сэндвич",
    "price": 388,
    "portion": "",
    "description": "Тостерный хлеб, курица копчёная, салатный лист, огурцы, помидоры, соус от шефа, картофель фри, кетчуп.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sta-128",
    "category": "starters",
    "name": "Сырные палочки",
    "price": 228,
    "portion": "",
    "description": "Голландский сыр, соус «Тар-тар».",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sta-129",
    "category": "starters",
    "name": "Рулет из баклажанов",
    "price": 498,
    "portion": "",
    "description": "Говядина, болгарский перец, репчатый лук, кабачки, чеснок, сыр брынза,горчица зернистая, майонез.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sta-130",
    "category": "starters",
    "name": "Овощная нарезка",
    "price": 498,
    "portion": "",
    "description": "Огурцы, помидоры, репчатый лук, зелёный лук, кинза, болгарский перец,салат лист, сыр брынза.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sta-131",
    "category": "starters",
    "name": "Сырная нарезка",
    "price": 888,
    "portion": "",
    "description": "Голландский сыр, сыр брынза, сыр сулугуни, сыр моцарелла, грецкий орех, мёд.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "sta-132",
    "category": "starters",
    "name": "Мясная нарезка",
    "price": 988,
    "portion": "",
    "description": "Чучук, жая, копчёная куриная грудка, копчёный куриный рулет.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ba-133",
    "category": "bakery",
    "name": "Чак-чак",
    "price": 228,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ba-134",
    "category": "bakery",
    "name": "Талкан",
    "price": 188,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ba-135",
    "category": "bakery",
    "name": "Боорсок с каймаком",
    "price": 258,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "ba-136",
    "category": "bakery",
    "name": "Нан",
    "price": 58,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-137",
    "category": "sides",
    "name": "Картофельное пюре",
    "price": 180,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-138",
    "category": "sides",
    "name": "Картофель фри",
    "price": 220,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-139",
    "category": "sides",
    "name": "Картофель по-деревенски",
    "price": 250,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-140",
    "category": "sides",
    "name": "Крокеты",
    "price": 250,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-141",
    "category": "sides",
    "name": "Сливочный",
    "price": 88,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-142",
    "category": "sides",
    "name": "Сырный",
    "price": 88,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-143",
    "category": "sides",
    "name": "Тартар",
    "price": 88,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-144",
    "category": "sides",
    "name": "Чесночный",
    "price": 88,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-145",
    "category": "sides",
    "name": "Майонез",
    "price": 58,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-146",
    "category": "sides",
    "name": "Кетчуп",
    "price": 48,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-147",
    "category": "sides",
    "name": "Халапеньо",
    "price": 88,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-148",
    "category": "sides",
    "name": "Каймак домашний",
    "price": 99,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-149",
    "category": "sides",
    "name": "Сметана",
    "price": 48,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "si-150",
    "category": "sides",
    "name": "Лазы",
    "price": 38,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-151",
    "category": "drinks",
    "name": "Зеленый чай",
    "price": 180,
    "portion": "800 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-152",
    "category": "drinks",
    "name": "Черный чай",
    "price": 180,
    "portion": "800 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-153",
    "category": "drinks",
    "name": "Ароматный чай",
    "price": 268,
    "portion": "800 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-154",
    "category": "drinks",
    "name": "Ягодный",
    "price": 348,
    "portion": "800 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-155",
    "category": "drinks",
    "name": "Эспрессо",
    "price": 118,
    "portion": "35 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-156",
    "category": "drinks",
    "name": "Американо",
    "price": 148,
    "portion": "150 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-157",
    "category": "drinks",
    "name": "Капучино",
    "price": 218,
    "portion": "250 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-158",
    "category": "drinks",
    "name": "Латте",
    "price": 238,
    "portion": "250 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-159",
    "category": "drinks",
    "name": "Раф",
    "price": 278,
    "portion": "250 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-160",
    "category": "drinks",
    "name": "Мокко",
    "price": 278,
    "portion": "250 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-161",
    "category": "drinks",
    "name": "Айс Бамбл",
    "price": 318,
    "portion": "эспрессо, вода, мед, лед",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-162",
    "category": "drinks",
    "name": "Айс Латте",
    "price": 308,
    "portion": "эспрессо, молоко, лед",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-163",
    "category": "drinks",
    "name": "Эспрессо-тоник",
    "price": 248,
    "portion": "",
    "description": "эспрессо, тоник",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-164",
    "category": "drinks",
    "name": "Малина -тоник",
    "price": 248,
    "portion": "эспрессо, лед, сок малины",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-165",
    "category": "drinks",
    "name": "Сок «Самоор»",
    "price": 248,
    "portion": "400 мл / 1 л",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-166",
    "category": "drinks",
    "name": "Лимонад «Самоор»",
    "price": 248,
    "portion": "400 мл / 1 л",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-167",
    "category": "drinks",
    "name": "Компот «Самоор»",
    "price": 178,
    "portion": "400 мл / 1 л",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-168",
    "category": "drinks",
    "name": "Шоты «Самоор»",
    "price": 248,
    "portion": "200 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-169",
    "category": "drinks",
    "name": "Манго–маракуйя",
    "price": 248,
    "portion": "400 мл / 1 л",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-170",
    "category": "drinks",
    "name": "Ягодный",
    "price": 248,
    "portion": "400 мл / 1 л",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-171",
    "category": "drinks",
    "name": "Апельсиновый",
    "price": 248,
    "portion": "400 мл / 1 л",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-172",
    "category": "drinks",
    "name": "Киви–апельсин",
    "price": 248,
    "portion": "400 мл / 1 л",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-173",
    "category": "drinks",
    "name": "Ягодный",
    "price": 308,
    "portion": "300 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-174",
    "category": "drinks",
    "name": "Орео",
    "price": 318,
    "portion": "300 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-175",
    "category": "drinks",
    "name": "Банановый",
    "price": 278,
    "portion": "300 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-176",
    "category": "drinks",
    "name": "Классический",
    "price": 248,
    "portion": "300 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-177",
    "category": "drinks",
    "name": "Молочный коктейль",
    "price": 248,
    "portion": "300 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-178",
    "category": "drinks",
    "name": "Цитрусовый",
    "price": 238,
    "portion": "200 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-179",
    "category": "drinks",
    "name": "Мохито",
    "price": 238,
    "portion": "200 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-180",
    "category": "drinks",
    "name": "Имбирный",
    "price": 268,
    "portion": "200 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-181",
    "category": "drinks",
    "name": "Клубничный",
    "price": 248,
    "portion": "200 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-182",
    "category": "drinks",
    "name": "Легенда 1 л",
    "price": 98,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-183",
    "category": "drinks",
    "name": "Байтик",
    "price": 118,
    "portion": "",
    "description": "газ.",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-184",
    "category": "drinks",
    "name": "Кола 1 л",
    "price": 178,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-185",
    "category": "drinks",
    "name": "Кола стекло",
    "price": 158,
    "portion": "250 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-186",
    "category": "drinks",
    "name": "Фанта 1 л",
    "price": 178,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-187",
    "category": "drinks",
    "name": "Спрайт 1 л",
    "price": 178,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-188",
    "category": "drinks",
    "name": "Schweppes 1 л",
    "price": 278,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-189",
    "category": "drinks",
    "name": "Айран 1 л",
    "price": 178,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-190",
    "category": "drinks",
    "name": "Максым 1 л",
    "price": 178,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-191",
    "category": "drinks",
    "name": "Чалап 1 л",
    "price": 178,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-192",
    "category": "drinks",
    "name": "Бозо облепиха 1 л",
    "price": 178,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-193",
    "category": "drinks",
    "name": "Жарма 1 л",
    "price": 178,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-194",
    "category": "drinks",
    "name": "Апельсиновый",
    "price": 348,
    "portion": "250 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-195",
    "category": "drinks",
    "name": "Яблочный",
    "price": 298,
    "portion": "250 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "dr-196",
    "category": "drinks",
    "name": "Морковный",
    "price": 248,
    "portion": "250 мл",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "mar-197",
    "category": "marinades",
    "name": "Баранина на косточках",
    "price": 1500,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "mar-198",
    "category": "marinades",
    "name": "Говядина",
    "price": 1600,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "mar-199",
    "category": "marinades",
    "name": "Мякоть баранины",
    "price": 1600,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "mar-200",
    "category": "marinades",
    "name": "Куриное филе",
    "price": 1960,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "mar-201",
    "category": "marinades",
    "name": "Курица на костях",
    "price": 1400,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "mar-202",
    "category": "marinades",
    "name": "Кебаб",
    "price": 1300,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "mar-203",
    "category": "marinades",
    "name": "Крылышки",
    "price": 1450,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  },
  {
    "id": "mar-204",
    "category": "marinades",
    "name": "Утиные грудки",
    "price": 1200,
    "portion": "",
    "description": "",
    "image": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60"
  }
];
